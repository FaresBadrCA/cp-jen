Jen is a configurable test case generator for competitive programming.
The format of the test cases is specified in a TOML configuration file.
Supplied with a test and a reference program, Jen will generate test cases and supply them to the test and ref programs
through standard input and compare the outputs of the two programs. If a difference in outputs is found, the test case is saved to a file.

install with `pip install cp-jen`
then run `jen <config.toml> <test_program> <reference_program>`

The specifications for the configuration file are detailed below.
